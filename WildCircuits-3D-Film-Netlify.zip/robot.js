import * as THREE from './vendor/three.module.min.js';
import { makeRobot, createStudio, makeShadow } from './model.js';
import { shots, clamp, lerp, smooth } from './director.js';
import { soundKit, createGlintPass } from './post.js';

const shotById = Object.fromEntries(shots.map((shot) => [shot.id, shot]));
const driveTestShot = {
  ...shotById.robot, angle: .64, elevation: .42, frame: 654,
  focus: [0, 103, 12], x: -.21, y: -.02, phoneFrame: 536, phoneY: .19,
};
const driveCommands = {
  left: { x: -1, z: 0, gears: [1, -1, -1, 1], label: 'STRAFE LEFT / OPPOSITE CORNERS TURN TOGETHER' },
  forward: { x: 0, z: 1, gears: [1, 1, 1, 1], label: 'FORWARD / ALL FOUR WHEELS TURN TOGETHER' },
  right: { x: 1, z: 0, gears: [-1, 1, 1, -1], label: 'STRAFE RIGHT / OPPOSITE CORNERS TURN TOGETHER' },
};

function stageFloor() {
  const material = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    uniforms: { power: { value: 0 }, time: { value: 0 }, wire: { value: 0 } },
    vertexShader: `
      varying vec2 surface;
      void main() {
        surface = position.xy;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.);
      }
    `,
    fragmentShader: `
      uniform float power;
      uniform float time;
      uniform float wire;
      varying vec2 surface;
      void main() {
        float r = length(surface);
        float fade = 1. - smoothstep(150., 675., r);
        vec2 gridPos = surface / 37.;
        vec2 grid = abs(fract(gridPos - .5) - .5) / max(fwidth(gridPos), vec2(.001));
        float thin = 1. - min(min(grid.x, grid.y), 1.);
        float ring = 1. - smoothstep(.5, 2.3, abs(r - 293.));
        float outer = 1. - smoothstep(.3, 1.55, abs(r - 339.));
        float tick = step(.58, fract(atan(surface.y, surface.x) * 19.1));
        float live = 1. - smoothstep(0., 5., abs(r - (173. + mod(time * 144., 266.))));
        float liveFade = (1. - smoothstep(170., 452., r)) * power;
        float alpha = (thin * .12 + ring * .53 + outer * (.07 + tick * .34)) * fade + live * liveFade * .7;
        vec3 floor = mix(vec3(.36, .26, .56), vec3(.49, .61, .92), wire);
        floor = mix(floor, vec3(.73, .95, .21), live * liveFade);
        gl_FragColor = vec4(floor, alpha);
        #include <colorspace_fragment>
      }
    `,
  });
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(1480, 1480), material);
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = .3;
  return floor;
}

export async function mountRobot(film, director, gl) {
  const stage = film.querySelector('.cinema');
  const canvas = stage.querySelector('canvas');
  const tools = film.querySelector('#stage-tools');
  const orbitTools = film.querySelector('.orbit-actions');
  const driveDemo = film.querySelector('.drive-demo');
  const driveButtons = Array.from(driveDemo.querySelectorAll('[data-drive]'));
  const driveReadout = driveDemo.querySelector('#drive-readout');
  const intakeButton = film.querySelector('[data-action=intake]');
  const intakeText = intakeButton.querySelector('span');
  const status = film.querySelector('#stage-status');
  const renderLabel = film.querySelector('#render-label');
  const powerButtons = Array.from(film.querySelectorAll('[data-action=power]'));
  const mobile = matchMedia('(max-width: 760px)');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const sound = soundKit();
  const getButton = (name) => tools.querySelector('[data-action=' + name + ']');
  const setPressed = (button, active) => {
    const value = String(active);
    if (button.getAttribute('aria-pressed') !== value) button.setAttribute('aria-pressed', value);
  };
  const announce = (text) => { status.textContent = text; };

  const renderer = new THREE.WebGLRenderer({ canvas, context: gl, alpha: true, antialias: true });
  renderer.setClearColor(0x000000, 0);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.24;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene = new THREE.Scene();
  const studio = createStudio(renderer);
  scene.environment = studio.texture;
  scene.environmentIntensity = 1.18;

  scene.add(new THREE.HemisphereLight(0xe8ddff, 0x4e3551, .76));
  const key = new THREE.DirectionalLight(0xffe6ce, 2.06);
  key.position.set(252, 410, 369);
  scene.add(key);
  const rim = new THREE.DirectionalLight(0xb9c6ff, 1.67);
  rim.position.set(-278, 170, -342);
  scene.add(rim);

  const camera = new THREE.PerspectiveCamera(37, 1, 3, 4000);
  const { model, parts, pins, wheels, intakeRollers, emitter } = makeRobot();
  const shadow = makeShadow();
  const floor = stageFloor();
  scene.add(model, floor, shadow);
  floor.renderOrder = -2;
  shadow.renderOrder = -1;

  let bloom = !reduced.matches && Boolean(gl.getExtension('EXT_color_buffer_float'));
  const glints = bloom ? createGlintPass() : null;
  let ratio = Math.min(devicePixelRatio, mobile.matches ? 1.3 : 1.6, 1.75);
  let width = 1;
  let height = 1;
  const drawSize = new THREE.Vector2();
  function resize() {
    width = Math.max(1, stage.clientWidth);
    height = Math.max(1, stage.clientHeight);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setPixelRatio(ratio);
    renderer.setSize(width, height, false);
    if (bloom) {
      renderer.getDrawingBufferSize(drawSize);
      glints.resize(drawSize.x, drawSize.y);
    }
  }

  const lineLayer = stage.querySelector('#leaders');
  const projected = new THREE.Vector3();
  for (const pin of pins) {
    pin.label = stage.querySelector('[data-pin=' + pin.name + ']');
    pin.line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    pin.dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    pin.dot.setAttribute('r', '2.7');
    lineLayer.append(pin.line, pin.dot);
  }

  function updateCallouts() {
    model.updateMatrixWorld(true);
    const labelPoints = pins.map((pin) => {
      const left = pin.name === 'frame' || pin.name === 'intake';
      return {
        x: pin.label.offsetLeft + (left ? pin.label.offsetWidth : 0),
        y: pin.label.offsetTop + pin.label.offsetHeight * .5,
        edge: left ? 18 : -18,
      };
    });
    for (const [index, pin] of pins.entries()) {
      projected.copy(pin.at);
      pin.parent.localToWorld(projected);
      projected.project(camera);
      const x = clamp((projected.x + 1) * width / 2, 0, width).toFixed(1);
      const y = clamp((1 - projected.y) * height / 2, 0, height).toFixed(1);
      const label = labelPoints[index];
      pin.line.setAttribute('d', 'M' + x + ' ' + y + ' L' + (label.x + label.edge) + ' ' + label.y + ' H' + label.x);
      pin.dot.setAttribute('cx', x);
      pin.dot.setAttribute('cy', y);
    }
  }

  let surfaces = [];
  const blueprintLines = [];
  let blueprint = false;
  function prepareBlueprint() {
    if (surfaces.length || lost) return;
    const edges = new Map();
    const ink = new THREE.LineBasicMaterial({ color: 0xb9d9ff, transparent: true, opacity: .72 });
    model.traverse((object) => { if (object.isMesh) surfaces.push(object); });
    for (const surface of surfaces) {
      const mats = Array.isArray(surface.material) ? surface.material : [surface.material];
      if (mats.some((material) => material.map && material.transparent)) continue;
      const geometry = surface.geometry;
      if (!edges.has(geometry)) edges.set(geometry, new THREE.EdgesGeometry(geometry, 27));
      const lines = new THREE.LineSegments(edges.get(geometry), ink);
      lines.visible = false;
      surface.add(lines);
      blueprintLines.push(lines);
    }
  }
  function setBlueprint(active) {
    if (active) prepareBlueprint();
    blueprint = active;
    for (const mesh of surfaces) mesh.layers.set(active ? 1 : 0);
    for (const lines of blueprintLines) lines.visible = active;
    shadow.visible = !active;
    floor.material.uniforms.wire.value = Number(active);
    film.classList.toggle('is-blueprint', active);
    setPressed(getButton('blueprint'), active);
  }

  let orbit = 0;
  let pitch = 0;
  let pointerX = 0;
  let pointerY = 0;
  let drag = null;
  let powered = false;
  let enabledSound = false;
  let manualExplode = null;
  let held = null;
  let energy = 0;
  let spin = 0;
  let intakeSpin = 0;
  const wheelAngles = wheels.map(() => 0);
  let driveCycle = null;
  let driveFocusUntil = 0;
  let intakeUntil = 0;
  let time = 0;
  let beatSound = -1;
  let previousChapter = director.index;
  const look = new THREE.Vector3(...shots[0].focus);
  const aim = new THREE.Vector3();
  const pose = { ...shots[0] };

  function togglePower() {
    powered = !powered;
    for (const button of powerButtons) setPressed(button, powered);
    const label = film.querySelector('.power-trigger span');
    label.textContent = powered ? 'Hold to power down' : 'Hold to power up';
    announce(powered ? 'Robot powered on.' : 'Robot powered off.');
    sound.tick(true);
  }
  function cancelHold() {
    if (held) held.button.style.setProperty('--charge', '0');
    held = null;
  }
  for (const button of powerButtons) {
    button.addEventListener('pointerdown', (event) => {
      if (event.button !== 0 || !event.isPrimary) return;
      button.setPointerCapture(event.pointerId);
      held = { button, since: performance.now(), done: false };
    });
    button.addEventListener('pointerup', () => {
      if (held && !held.done && performance.now() - held.since >= 650) {
        held.done = true;
        togglePower();
      }
      if (held && !held.done) {
        announce('Hold the power control to start the robot.');
        button.classList.remove('hold-hint');
        requestAnimationFrame(() => button.classList.add('hold-hint'));
      }
      cancelHold();
    });
    button.addEventListener('pointercancel', cancelHold);
    button.addEventListener('lostpointercapture', cancelHold);
    button.addEventListener('click', (event) => {
      if (event.detail === 0) togglePower();
    });
  }

  function stopDrive() {
    driveCycle = null;
    for (const button of driveButtons) setPressed(button, false);
  }
  function stopIntake() {
    intakeUntil = 0;
    setPressed(intakeButton, false);
    intakeText.textContent = 'Cycle the intake';
  }
  for (const button of driveButtons) {
    button.addEventListener('click', () => {
      const command = driveCommands[button.dataset.drive];
      driveCycle = { command, start: performance.now() };
      driveFocusUntil = driveCycle.start + 2450;
      for (const option of driveButtons) setPressed(option, option === button);
      driveReadout.textContent = command.label;
      sound.tick(true);
    });
  }
  intakeButton.addEventListener('click', () => {
    intakeUntil = performance.now() + 1520;
    setPressed(intakeButton, true);
    intakeText.textContent = 'Intake cycling';
    announce('Intake test started.');
    sound.tick(true);
  });

  getButton('explode').addEventListener('click', () => {
    const active = getButton('explode').getAttribute('aria-pressed') === 'true';
    manualExplode = active ? 0 : 1;
    orbit = 0;
    pitch = 0;
    setPressed(getButton('explode'), !active);
    announce(active ? 'Robot reassembled.' : 'Exploded view. The robot assemblies separate with labeled callouts.');
    sound.tick(true);
  });
  getButton('blueprint').addEventListener('click', () => {
    setBlueprint(!blueprint);
    announce(blueprint ? 'Blueprint view.' : 'Solid materials view.');
    sound.tick();
  });
  getButton('sound').addEventListener('click', async () => {
    if (enabledSound) {
      sound.disable();
      enabledSound = false;
    } else {
      enabledSound = await sound.enable();
      if (enabledSound) sound.tick(true);
    }
    setPressed(getButton('sound'), enabledSound);
    announce(enabledSound ? 'Sound on.' : 'Sound off.');
  });
  getButton('reset').addEventListener('click', () => {
    manualExplode = null;
    orbit = 0;
    pitch = 0;
    if (powered) togglePower();
    stopDrive();
    driveFocusUntil = 0;
    stopIntake();
    driveReadout.textContent = 'CHOOSE A DRIVE INPUT';
    setBlueprint(false);
    announce('Camera reset to this chapter.');
  });
  film.querySelector('[data-action=orbit-left]').addEventListener('click', () => { orbit -= .32; });
  film.querySelector('[data-action=orbit-right]').addEventListener('click', () => { orbit += .32; });
  canvas.addEventListener('pointerdown', (event) => {
    if (event.button !== 0 || !event.isPrimary) return;
    drag = { id: event.pointerId, x: event.clientX, y: event.clientY };
    canvas.setPointerCapture(event.pointerId);
  });
  canvas.addEventListener('pointermove', (event) => {
    if (drag?.id === event.pointerId) {
      orbit += (event.clientX - drag.x) * .007;
      pitch = clamp(pitch - (event.clientY - drag.y) * .004, -.35, .56);
      drag.x = event.clientX;
      drag.y = event.clientY;
    }
    if (event.pointerType !== 'mouse') return;
    pointerX = clamp(event.clientX / width) * 2 - 1;
    pointerY = clamp(event.clientY / height) * 2 - 1;
  });
  function release(event) {
    if (drag?.id === event.pointerId) drag = null;
  }
  canvas.addEventListener('pointerup', release);
  canvas.addEventListener('pointercancel', release);
  canvas.addEventListener('lostpointercapture', release);
  canvas.addEventListener('pointerleave', () => { pointerX = 0; pointerY = 0; });
  canvas.addEventListener('keydown', (event) => {
    switch (event.key) {
      case 'ArrowLeft': orbit -= .2; break;
      case 'ArrowRight': orbit += .2; break;
      case 'ArrowUp': pitch = clamp(pitch + .11, -.35, .56); break;
      case 'ArrowDown': pitch = clamp(pitch - .11, -.35, .56); break;
      default: return;
    }
    event.preventDefault();
  });

  function draw(dt, now, cameraDt = dt) {
    const { from, to, blend, index } = director;
    if (index !== previousChapter) {
      previousChapter = index;
      manualExplode = null;
      orbit = 0;
      pitch = 0;
      cancelHold();
      stopDrive();
      driveFocusUntil = 0;
      stopIntake();
    }
    const noMotion = reduced.matches;
    const source = shots[noMotion ? index : from];
    const destination = shots[noMotion ? index : to];
    const forced = manualExplode === 1;
    const chapter = shots[index];
    const assembled = manualExplode === 0 && chapter.explode > 0;
    const testingDrive = chapter.id === 'robot' && now < driveFocusUntil;
    let shot = source;
    if (forced) shot = shotById.apart;
    else if (assembled) shot = shotById[chapter.id === 'orbit' ? 'field' : 'hero'];
    else if (testingDrive) shot = driveTestShot;
    const next = forced || assembled || testingDrive ? shot : destination;
    const position = (field) => lerp(shot[field], next[field], blend);
    const easing = noMotion || cameraDt === 0 ? 1 : 1 - Math.exp(-cameraDt * 8);
    const approach = (field, value) => { pose[field] = lerp(pose[field], value, easing); };
    const narrow = mobile.matches;
    const compact = height < 720;
    const portraitFrame = position('phoneFrame') * (compact ? 1.1 : 1);
    const portraitY = position('phoneY') - (compact ? .018 : 0);
    const orbitOffset = noMotion ? 0 : pointerX * .05;
    approach('angle', position('angle') + orbit + orbitOffset);
    approach('elevation', clamp(position('elevation') + pitch, .09, 1.31));
    approach('frame', narrow ? portraitFrame : position('frame'));
    approach('x', narrow ? 0 : position('x'));
    approach('y', narrow ? portraitY : position('y'));
    approach('explode', manualExplode ?? lerp(source.explode, destination.explode, blend));
    aim.set(...shot.focus.map((value, axis) => lerp(value, next.focus[axis], blend)));
    look.lerp(aim, easing);

    const radius = pose.frame / (2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2))) / Math.min(1, camera.aspect);
    camera.setViewOffset(width, height, -pose.x * width, -pose.y * height, width, height);
    camera.position.set(
      look.x + Math.sin(pose.angle) * Math.cos(pose.elevation) * radius,
      look.y + Math.sin(pose.elevation) * radius,
      look.z + Math.cos(pose.angle) * Math.cos(pose.elevation) * radius,
    );
    camera.lookAt(look);
    camera.updateMatrixWorld();
    film.style.setProperty('--studio-x', (50 + pose.x * 100).toFixed(1) + '%');
    scene.environmentRotation.set(noMotion ? 0 : pointerY * .14, noMotion ? 0 : -pointerX * .30, 0);
    for (const part of parts) {
      const delay = (1 - part.order) * .38;
      part.object.position.copy(part.lift).multiplyScalar(smooth((pose.explode - delay) / .62));
    }

    if (held && !held.done) {
      const progress = clamp((now - held.since) / 650);
      held.button.style.setProperty('--charge', progress.toFixed(3));
      if (progress >= 1) {
        held.done = true;
        togglePower();
      }
    }
    energy = lerp(energy, Number(powered), easing * .7);
    const speed = noMotion ? 0 : lerp(source.speed, destination.speed, blend) + energy * 9;
    spin += dt * speed;
    if (driveCycle && now - driveCycle.start > 1280) stopDrive();
    if (intakeUntil && now >= intakeUntil) {
      stopIntake();
      announce('Intake test complete.');
    }
    const testingIntake = intakeUntil > 0;
    const command = driveCycle?.command;
    const distance = command && !noMotion ? 43 * smooth((now - driveCycle.start) / 1050) : 0;
    model.position.x = lerp(model.position.x, (command?.x ?? 0) * distance, easing);
    model.position.z = lerp(model.position.z, (command?.z ?? 0) * distance, easing);
    shadow.position.x = model.position.x;
    shadow.position.z = model.position.z;
    for (const [i, wheel] of wheels.entries()) {
      const gear = command && !noMotion ? command.gears[i] * 8.1 : speed;
      wheelAngles[i] += dt * gear;
      wheel.rotation.x = wheelAngles[i];
    }
    intakeSpin -= dt * (1.7 * speed + (testingIntake && !noMotion ? 10.4 : 0));
    for (const roller of intakeRollers) roller.rotation.x = intakeSpin;
    model.rotation.z = noMotion ? 0 : Math.sin(time * 10) * energy * (1 - pose.explode) * .006;
    emitter.emissiveIntensity = .21 + energy * (2.24 + (noMotion ? 0 : .45 * Math.sin(time * 7)));
    floor.material.uniforms.time.value = noMotion ? 0 : time;
    floor.material.uniforms.power.value = Math.max(energy, testingIntake ? .42 : 0);
    shadow.material.opacity = 1 - pose.explode * .58;
    const nextBeat = Math.floor(spin * 1.4);
    if (powered && nextBeat !== beatSound) {
      beatSound = nextBeat;
      sound.tick();
    }

    const showCallouts = pose.explode > .76 && pose.frame >= 500;
    stage.classList.toggle('has-callouts', showCallouts);
    if (showCallouts) updateCallouts();
    setPressed(getButton('explode'), manualExplode === 1 || (manualExplode === null && shots[index].explode > .5));

    if (bloom && !blueprint && !noMotion) glints.render(renderer, scene, camera);
    else renderer.render(scene, camera);
  }

  let ready = false;
  let lost = false;
  let frame = 0;
  let last = 0;
  let lastReview = 0;
  let samples = 0;
  let slow = 0;
  function loop(now) {
    frame = 0;
    if (!director.visible || document.hidden || lost) return;
    const delta = last ? (now - last) / 1000 : 0;
    last = now;
    if (delta > 0 && delta < 1.2) {
      samples += 1;
      if (delta > .025) slow += 1;
    }
    if (now - lastReview > 1400 && samples >= 4) {
      if (slow / samples > .68) {
        if (ratio > .78) {
          ratio = Math.max(.78, ratio - .23);
          resize();
        } else if (bloom) {
          bloom = false;
          glints.dispose();
        }
      }
      samples = slow = 0;
      lastReview = now;
    }
    const dt = clamp(delta, 0, .06);
    time += dt;
    draw(dt, now, clamp(delta, 0, .24));
    frame = requestAnimationFrame(loop);
  }

  function schedule() {
    const active = ready && director.visible && !lost && !document.hidden;
    if (active && !frame) {
      last = 0;
      lastReview = performance.now();
      samples = slow = 0;
      frame = requestAnimationFrame(loop);
    } else if (!active && frame) {
      cancelAnimationFrame(frame);
      frame = 0;
    }
  }
  director.change = schedule;
  document.addEventListener('visibilitychange', schedule);
  new ResizeObserver(() => { if (!lost) resize(); }).observe(stage);
  canvas.addEventListener('webglcontextlost', () => {
    lost = true;
    schedule();
    film.classList.remove('is-live', 'is-blueprint');
    stage.classList.remove('has-callouts');
    tools.hidden = true;
    orbitTools.hidden = true;
    driveDemo.hidden = true;
    intakeButton.hidden = true;
    for (const button of powerButtons) button.hidden = true;
    renderLabel.textContent = 'COMPETITION PHOTO';
    canvas.tabIndex = -1;
    canvas.setAttribute('aria-hidden', 'true');
    announce('Live 3D is unavailable. Showing the competition photo.');
  }, { once: true });

  resize();
  await renderer.compileAsync(scene, camera);
  if (lost) return;
  if (bloom) await glints.compile(renderer);
  if (lost) return;
  draw(0, performance.now());
  film.classList.add('is-live');
  renderLabel.textContent = 'LIVE 3D / MODEL STUDY';
  canvas.removeAttribute('aria-hidden');
  canvas.setAttribute('aria-label', 'Live 3D robot. Drag or use the arrow keys to rotate.');
  canvas.tabIndex = director.visible ? 0 : -1;
  tools.hidden = false;
  orbitTools.hidden = false;
  driveDemo.hidden = false;
  intakeButton.hidden = false;
  for (const button of powerButtons) button.hidden = false;
  ready = true;
  schedule();
  if ('requestIdleCallback' in window) requestIdleCallback(prepareBlueprint);
}


