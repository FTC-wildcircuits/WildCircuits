import { startDirector } from './director.js';

const select = (selector) => document.querySelector(selector);
const menu = select('.menu-toggle');
const labMenu = select('.lab-menu');
const nav = select('#navigation');

function closeMenu() {
  menu.setAttribute('aria-expanded', 'false');
  menu.querySelector('use').setAttribute('href', '#menu');
  nav.classList.remove('is-open');
}

menu.addEventListener('click', () => {
  const open = menu.getAttribute('aria-expanded') === 'true';
  if (open) {
    closeMenu();
    return;
  }
  labMenu.open = false;
  menu.setAttribute('aria-expanded', 'true');
  menu.querySelector('use').setAttribute('href', '#close');
  nav.classList.add('is-open');
});
nav.addEventListener('click', (event) => {
  if (event.target.closest('a')) closeMenu();
});
labMenu.addEventListener('click', (event) => {
  if (event.target.closest('.film-chapters a')) labMenu.open = false;
});
labMenu.addEventListener('toggle', () => { if (labMenu.open) closeMenu(); });
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && labMenu.open) {
    labMenu.open = false;
    labMenu.querySelector('summary').focus();
  }
  if (event.key === 'Escape' && nav.classList.contains('is-open')) {
    closeMenu();
    menu.focus();
  }
});

function setupFilter(group, apply) {
  group.hidden = false;
  const buttons = Array.from(group.querySelectorAll('button'));
  group.addEventListener('click', (event) => {
    const choice = event.target.closest('button');
    if (!choice) return;
    for (const button of buttons) button.setAttribute('aria-pressed', button === choice);
    apply(choice.dataset.value);
  });
}

const phasePanels = Array.from(document.querySelectorAll('[data-phase-panel]'));
function showPhase(id) {
  for (const panel of phasePanels) panel.hidden = panel.dataset.phasePanel !== id;
}
showPhase('auto');
setupFilter(select('.phase-options'), showPhase);

const members = Array.from(document.querySelectorAll('.crew-grid [data-role]'));
setupFilter(select('[data-filter=crew]'), (role) => {
  let count = 0;
  for (const member of members) {
    member.hidden = role !== 'all' && !member.dataset.role.split(' ').includes(role);
    if (!member.hidden) count += 1;
  }
  select('.crew-cta').hidden = role !== 'all';
  select('#crew-count').textContent = count === 1 ? '01 TEAMMATE' : String(count).padStart(2, '0') + ' TEAMMATES';
});

const events = Array.from(document.querySelectorAll('.events [data-end]'));
function showSeason(filter) {
  let next = true;
  let visible = 0;
  for (const event of events) {
    const past = Date.parse(event.dataset.end) < Date.now();
    const featured = next && !past;
    if (featured) next = false;
    event.classList.toggle('next', featured);
    event.hidden = filter === 'upcoming' && past;
    event.querySelector('.event-status').textContent = past ? 'Completed' : featured ? 'Next event' : 'Upcoming';
    if (!event.hidden) visible += 1;
  }
  select('.empty-events').hidden = visible > 0;
}
showSeason('all');
setupFilter(select('[data-filter=season]'), showSeason);

const form = select('#contact-form');
const status = select('#form-status');
const copy = select('#copy-message');
let draft = '';
form.hidden = false;
form.addEventListener('input', () => {
  status.hidden = true;
  copy.textContent = 'copy your message';
});
form.addEventListener('submit', (event) => {
  event.preventDefault();
  const fields = new FormData(form);
  const name = fields.get('name').trim();
  const organization = fields.get('organization').trim();
  const email = fields.get('email').trim();
  const message = fields.get('message').trim();
  const subject = 'WildCircuits 36611 — ' + fields.get('topic');
  const signature = [name, organization, email].filter(Boolean).join('\n');
  draft = message + '\n\n' + signature;
  status.hidden = false;
  window.location.href = 'mailto:ftc36611@gmail.com?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(draft.replace(/\r?\n/g, '\r\n'));
});
copy.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(draft);
    copy.textContent = 'message copied';
  } catch {
    copy.textContent = 'select and copy your message in the form';
    form.elements.message.select();
  }
});

const film = select('#film');
const canvas = select('#robot-canvas');
const label = select('#render-label');
const director = startDirector();

async function initRobot() {
  try {
    const gl = canvas.getContext('webgl2', { antialias: true, alpha: true, powerPreference: 'high-performance' });
    if (!gl) {
      label.textContent = 'COMPETITION PHOTO';
      return;
    }
    label.textContent = 'LOADING LIVE 3D';
    const { mountRobot } = await import('./robot.js');
    await mountRobot(film, director, gl);
  } catch (error) {
    label.textContent = 'COMPETITION PHOTO';
    console.warn('Showing the competition photo in place of WebGL.', error);
  }
}
function startWhenVisible() {
  if (!director.visible) return;
  director.change = null;
  requestAnimationFrame(() => requestAnimationFrame(initRobot));
}
if (director.visible) startWhenVisible();
else director.change = startWhenVisible;

