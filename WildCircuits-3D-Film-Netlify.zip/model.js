import * as THREE from './vendor/three.module.min.js';

const { PI, cos, sin } = Math;
const vector = (x, y, z) => new THREE.Vector3(x, y, z);
const axisY = vector(0, 1, 0);
const axisX = vector(1, 0, 0);

function brushTexture() {
  const width = 128;
  const bytes = new Uint8Array(width * 4);
  let seed = 19;
  for (let i = 0; i < width; i += 1) {
    seed = (1664525 * seed + 1013904223) >>> 0;
    bytes.set([254, 129, 165 + (seed % 91), 255], i * 4);
  }
  const texture = new THREE.DataTexture(bytes, width, 1);
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearFilter;
  texture.wrapS = THREE.RepeatWrapping;
  texture.needsUpdate = true;
  return texture;
}

function turnedTexture() {
  const side = 64;
  const bytes = new Uint8Array(side * side * 4);
  for (let y = 0; y < side; y += 1) {
    for (let x = 0; x < side; x += 1) {
      const dx = x - (side - 1) / 2;
      const dy = y - (side - 1) / 2;
      const length = Math.hypot(dx, dy) || 1;
      const index = (y * side + x) * 4;
      bytes[index] = Math.round((1 - dy / length) * 127.5);
      bytes[index + 1] = Math.round((1 + dx / length) * 127.5);
      bytes[index + 2] = 232 - Math.floor(length * 3) % 29;
      bytes[index + 3] = 255;
    }
  }
  const texture = new THREE.DataTexture(bytes, side, side);
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearFilter;
  texture.needsUpdate = true;
  return texture;
}

function materials() {
  const physical = (options) => new THREE.MeshPhysicalMaterial(options);
  const brush = brushTexture();
  return {
    aluminum: physical({ color: 0xa0a4b5, metalness: 1, roughness: .36, anisotropy: .83, anisotropyMap: brush }),
    edge: physical({ color: 0xe0e2ec, metalness: 1, roughness: .18 }),
    red: physical({ color: 0xa41925, metalness: .30, roughness: .31, clearcoat: .65 }),
    redEdge: physical({ color: 0xe34649, metalness: .54, roughness: .24, clearcoat: .45 }),
    gold: physical({ color: 0xf9be38, metalness: .77, roughness: .28, anisotropy: .68, anisotropyMap: turnedTexture() }),
    rubber: physical({ color: 0x1a1921, roughness: .72, metalness: .02 }),
    plastic: physical({ color: 0x282530, roughness: .42, metalness: .07 }),
    carbon: physical({ color: 0x353344, roughness: .57, metalness: .32 }),
    wire: physical({ color: 0xb32d32, roughness: .42 }),
    wireDark: physical({ color: 0x302e40, roughness: .61 }),
    white: physical({ color: 0xe2e4e6, roughness: .43 }),
    emitter: physical({ color: 0x5b7520, roughness: .32, emissive: 0xcaff52, emissiveIntensity: .15 }),
  };
}

function roundedOutline(width, height, r) {
  const x = -width / 2;
  const y = -height / 2;
  const shape = new THREE.Shape();
  shape.moveTo(x + r, y);
  shape.lineTo(-x - r, y);
  shape.quadraticCurveTo(-x, y, -x, y + r);
  shape.lineTo(-x, -y - r);
  shape.quadraticCurveTo(-x, -y, -x - r, -y);
  shape.lineTo(x + r, -y);
  shape.quadraticCurveTo(x, -y, x, -y - r);
  shape.lineTo(x, y + r);
  shape.quadraticCurveTo(x, y, x + r, y);
  return shape;
}

function extrudedPlate(width, height, depth, corner, holes = []) {
  const shape = roundedOutline(width, height, corner);
  for (const [x, y, radius] of holes) {
    const cutout = new THREE.Path();
    cutout.absarc(x, y, radius, 0, PI * 2, true);
    shape.holes.push(cutout);
  }
  const bevel = Math.min(depth * .18, .55);
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth,
    curveSegments: 8,
    steps: 1,
    bevelEnabled: true,
    bevelSize: bevel,
    bevelThickness: bevel,
    bevelSegments: 1,
  });
  return geo.translate(0, 0, -depth / 2);
}

// Trace a rounded triangular gusset in millimetres using the signed distance
// to its three face lines. The bracket is convex so each ray crosses once.
function tracedGusset() {
  const profile = (x, y) => Math.max(-y - 21, x * .804 + y * .594 - 18, -x * .804 + y * .594 - 18) - 2.4;
  const shape = new THREE.Shape();
  for (let i = 0; i < 96; i += 1) {
    const angle = i / 96 * PI * 2;
    const direction = [cos(angle), sin(angle)];
    let inner = 0;
    let outer = 75;
    for (let step = 0; step < 17; step += 1) {
      const radius = (inner + outer) / 2;
      if (profile(direction[0] * radius, direction[1] * radius) > 0) outer = radius;
      else inner = radius;
    }
    const point = direction.map((axis) => axis * inner);
    if (i === 0) shape.moveTo(...point);
    else shape.lineTo(...point);
  }
  shape.closePath();
  for (const [x, y] of [[0, 14], [-14, -12], [14, -12]]) {
    const cut = new THREE.Path();
    cut.absarc(x, y, 3.15, 0, PI * 2, true);
    shape.holes.push(cut);
  }
  return new THREE.ExtrudeGeometry(shape, {
    depth: 4.1, steps: 1, curveSegments: 10,
    bevelEnabled: true, bevelSize: .05, bevelThickness: .05, bevelSegments: 1,
  }).translate(0, 0, -2.05);
}

function perforations(columns, spacing, row = 12) {
  const holes = [];
  for (let i = 0; i < columns; i += 1) {
    const x = (i - (columns - 1) / 2) * spacing;
    holes.push([x, 0, i % 2 === 0 ? 6.3 : 4]);
    if (row) holes.push([x, row, 2.15], [x, -row, 2.15]);
  }
  return holes;
}

function mesh(parent, geometry, material, x = 0, y = 0, z = 0) {
  const object = new THREE.Mesh(geometry, material);
  object.position.set(x, y, z);
  parent.add(object);
  return object;
}

function bar(parent, from, to, size, material) {
  const direction = to.clone().sub(from);
  const center = from.clone().addScaledVector(direction, .5);
  const object = mesh(parent, new THREE.BoxGeometry(size, direction.length(), size), material);
  object.position.copy(center);
  object.quaternion.setFromUnitVectors(axisY, direction.normalize());
  return object;
}

function wire(parent, coordinates, material, radius = 2.2) {
  const points = coordinates.map((xyz) => vector(...xyz));
  const curve = new THREE.CatmullRomCurve3(points);
  mesh(parent, new THREE.TubeGeometry(curve, 19, radius, 5, false), material);
}

function decal(text, subtitle = '') {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 180;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#fff2e2';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = 'bold ' + (subtitle ? '100' : '127') + 'px Arial';
  ctx.fillText(text, 256, subtitle ? 67 : 91, 470);
  if (subtitle) {
    ctx.font = 'bold 32px monospace';
    ctx.fillText(subtitle, 256, 143, 460);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  return new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false, side: THREE.FrontSide });
}

function makeWheel(parent, x, z, hand, m, geometry) {
  const rotor = new THREE.Group();
  rotor.position.set(x, 51.5, z);
  parent.add(rotor);
  const hub = mesh(rotor, geometry.hub, m.carbon);
  hub.rotation.z = PI / 2;
  for (const side of [-1, 1]) {
    const rim = mesh(rotor, geometry.rim, m.gold, side * 19);
    rim.rotation.z = PI / 2;
    const cap = mesh(rotor, geometry.cap, m.edge, side * 25);
    cap.rotation.z = PI / 2;
    for (let i = 0; i < 6; i += 1) {
      const angle = i * PI / 3;
      const screw = mesh(rotor, geometry.bolt, m.edge, side * 23, cos(angle) * 28, sin(angle) * 28);
      screw.rotation.z = PI / 2;
    }
  }
  for (let i = 0; i < 9; i += 1) {
    const angle = (i / 9) * PI * 2;
    const roller = mesh(rotor, geometry.roller, m.rubber, 0, cos(angle) * 38.6, sin(angle) * 38.6);
    roller.quaternion.setFromUnitVectors(axisY, vector(1, -sin(angle) * hand * .94, cos(angle) * hand * .94).normalize());
    const insert = mesh(rotor, geometry.axle, m.gold);
    insert.position.copy(roller.position);
    insert.quaternion.copy(roller.quaternion);
  }
  return rotor;
}

export function makeRobot() {
  const model = new THREE.Group();
  const parts = [];
  const wheels = [];
  const intakeRollers = [];
  const m = materials();
  const panelMetal = [m.aluminum, m.edge];
  const makePart = (name, order, lift) => {
    const object = new THREE.Group();
    object.name = name;
    model.add(object);
    const part = { object, order, lift: vector(...lift) };
    parts.push(part);
    return part;
  };

  const frame = makePart('Chassis', .14, [0, -29, -12]);
  const frameBeam = extrudedPlate(345, 43, 5.5, 4, perforations(15, 21));
  const crossBeam = extrudedPlate(316, 42, 5.5, 4, perforations(14, 21));
  const railTop = new THREE.BoxGeometry(345, 4.5, 24);
  const crossTop = new THREE.BoxGeometry(316, 4.5, 21);
  for (const side of [-1, 1]) {
    mesh(frame.object, frameBeam, panelMetal, side * 154, 64, -5).rotation.y = PI / 2;
    mesh(frame.object, railTop, m.aluminum, side * 145, 85, -5).rotation.y = PI / 2;
    mesh(frame.object, frameBeam, panelMetal, side * 132, 64, -5).rotation.y = PI / 2;
    mesh(frame.object, crossBeam, panelMetal, 0, 65, side * 153);
    mesh(frame.object, crossTop, m.edge, 0, 86, side * 148);
  }
  const floor = mesh(frame.object, extrudedPlate(287, 281, 3, 12, perforations(7, 30, 75)), [m.carbon, m.edge], 0, 54, -7);
  floor.rotation.x = -PI / 2;
  for (const x of [-98, 97]) {
    mesh(frame.object, new THREE.BoxGeometry(15, 10, 281), m.edge, x, 57, -7);
  }
  for (const x of [-143, 143]) {
    for (const z of [-147, 146]) {
      const motor = mesh(frame.object, new THREE.CylinderGeometry(17, 17, 59, 16), m.plastic, x, 53, z);
      motor.rotation.z = PI / 2;
      mesh(frame.object, new THREE.BoxGeometry(22, 47, 49), m.carbon, x, 60, z);
      wire(frame.object, [[x, 64, z], [x * .8, 79, z * .82], [x * .6, 77, z * .29]], m.wire, 2.4);
    }
  }

  const wheelGeometry = {
    hub: new THREE.CylinderGeometry(38, 38, 40, 30),
    rim: new THREE.CylinderGeometry(42, 42, 4.5, 28),
    cap: new THREE.CylinderGeometry(13, 13, 9, 14),
    bolt: new THREE.CylinderGeometry(3.4, 3.4, 2.6, 6),
    roller: new THREE.CapsuleGeometry(10.1, 27, 4, 9),
    axle: new THREE.CylinderGeometry(3.6, 3.6, 51, 8),
  };
  const wheelParts = [];
  for (const x of [-1, 1]) {
    for (const z of [-1, 1]) {
      const assembly = makePart('Mecanum wheel', .36, [x * 65, 8, z * 58]);
      wheels.push(makeWheel(assembly.object, x * 172, z * 139, x * z, m, wheelGeometry));
      wheelParts.push(assembly);
    }
  }

  const uprights = makePart('Uprights', .74, [0, 64, -49]);
  const gusset = tracedGusset();
  for (const side of [-1, 1]) {
    const bracket = mesh(uprights.object, gusset, panelMetal, side * 113, 86, 54);
    bracket.rotation.y = side * PI / 2;
    bracket.rotation.z = side * .28;
  }
  const uprightGeo = extrudedPlate(176, 25, 5, 4, perforations(10, 16, 0));
  const upperCross = extrudedPlate(243, 25, 4, 4, perforations(12, 18, 0));
  for (const side of [-1, 1]) {
    const upright = mesh(uprights.object, uprightGeo, panelMetal, side * 93, 154, -61);
    upright.rotation.set(-.19, PI / 2, PI / 2);
    const second = mesh(uprights.object, uprightGeo, panelMetal, side * 107, 144, 43);
    second.rotation.set(.32, PI / 2, PI / 2);
    bar(uprights.object, vector(side * 123, 88, 78), vector(side * 90, 233, -51), 11, m.edge);
    bar(uprights.object, vector(side * 119, 87, -133), vector(side * 96, 225, -30), 10, m.aluminum);
  }
  mesh(uprights.object, upperCross, panelMetal, 0, 221, -47);
  mesh(uprights.object, upperCross, panelMetal, 0, 195, 32);
  const deck = mesh(uprights.object, extrudedPlate(195, 109, 3.5, 8, perforations(9, 19, 28)), panelMetal, 0, 216, -24);
  deck.rotation.x = -1.15;

  const control = makePart('Control and wiring', .91, [111, 155, -44]);
  const unit = new THREE.Group();
  unit.position.set(-53, 144, -68);
  unit.rotation.set(-.32, 0, -.05);
  control.object.add(unit);
  mesh(unit, extrudedPlate(83, 102, 25, 6), [m.plastic, m.carbon]);
  const controlLabel = decal('REV', 'EXPANSION HUB');
  mesh(unit, new THREE.PlaneGeometry(64, 31), controlLabel, 0, 5, 14);
  const led = mesh(unit, new THREE.CylinderGeometry(2.6, 2.6, 1.7, 12), m.emitter, 27, 39, 14);
  led.rotation.x = PI / 2;
  for (let i = 0; i < 6; i += 1) {
    mesh(unit, new THREE.BoxGeometry(8.5, 11, 8.5), i % 2 ? m.carbon : m.white, -30 + i * 12, -43, 13);
  }
  mesh(control.object, extrudedPlate(47, 78, 25, 5), [m.carbon, m.plastic], 64, 114, -66);
  mesh(control.object, new THREE.BoxGeometry(37, 7, 6), m.gold, 64, 152, -52);
  wire(control.object, [[-64, 188, -79], [-83, 228, -73], [-56, 241, -2], [32, 222, 28], [104, 171, 0], [106, 93, -71]], m.wire, 3.2);
  wire(control.object, [[-45, 186, -84], [-63, 230, -77], [-26, 234, -12], [59, 218, 28], [118, 167, -19], [120, 95, -96]], m.wireDark, 3.5);
  wire(control.object, [[-75, 104, -53], [-87, 87, -10], [-69, 89, 43], [53, 83, 55], [106, 88, 100]], m.wire, 2.6);
  wire(control.object, [[-37, 111, -56], [-63, 86, -12], [-48, 85, 43], [56, 81, 52], [110, 81, 86]], m.wireDark, 2.9);

  const body = makePart('Number plates', 1, [-63, 176, 94]);
  const number = decal('36611');
  const plate = extrudedPlate(204, 62, 5, 7, [[-91, 22, 2.6], [91, 22, 2.6], [-91, -22, 2.6], [91, -22, 2.6]]);
  function numberPlate(x, y, z, pitch, yaw, scale = 1) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.set(pitch, yaw, 0, 'YXZ');
    group.scale.setScalar(scale);
    body.object.add(group);
    mesh(group, plate, [m.red, m.redEdge]);
    mesh(group, new THREE.PlaneGeometry(173, 55), number, 0, 1, 3.3);
    for (const sx of [-91, 91]) {
      for (const sy of [-22, 22]) {
        const bolt = mesh(group, wheelGeometry.bolt, m.edge, sx, sy, 3.4);
        bolt.rotation.x = PI / 2;
      }
    }
  }
  numberPlate(0, 180, 85, -.39, 0);
  numberPlate(112, 139, -22, -.18, PI / 2, .73);
  numberPlate(-112, 139, -22, -.18, -PI / 2, .73);

  const intake = makePart('Front roller', .57, [0, 37, 128]);
  const intakeBeam = extrudedPlate(284, 47, 5, 4, perforations(13, 20));
  mesh(intake.object, intakeBeam, panelMetal, 0, 102, 172);
  mesh(intake.object, new THREE.BoxGeometry(284, 5, 18), m.edge, 0, 127, 166);
  const shaft = mesh(intake.object, new THREE.CylinderGeometry(6, 6, 263, 12), m.edge, 0, 63, 174);
  shaft.rotation.z = PI / 2;
  const intakeGeo = new THREE.CylinderGeometry(22, 22, 11, 16);
  for (let i = -6; i <= 6; i += 1) {
    const rotor = new THREE.Group();
    rotor.position.set(i * 17, 64, 177);
    intake.object.add(rotor);
    const drum = mesh(rotor, intakeGeo, m.rubber);
    drum.rotation.z = PI / 2;
    for (let fin = 0; fin < 4; fin += 1) {
      const angle = fin * PI / 2 + i * .12;
      const paddle = mesh(rotor, new THREE.BoxGeometry(9, 17, 2.8), m.carbon, 0, sin(angle) * 22, cos(angle) * 22);
      paddle.rotation.x = angle + PI / 2;
    }
    intakeRollers.push(rotor);
  }
  for (const side of [-1, 1]) {
    const end = mesh(intake.object, extrudedPlate(55, 76, 5, 13, [[0, -16, 5.5], [0, 14, 6]]), panelMetal, side * 137, 84, 166);
    end.rotation.y = PI / 2;
  }

  const pins = [
    { name: 'frame', parent: frame.object, at: vector(-114, 71, 152) },
    { name: 'drive', parent: wheelParts[3].object, at: vector(193, 60, 146) },
    { name: 'hub', parent: control.object, at: vector(-53, 172, -54) },
    { name: 'intake', parent: intake.object, at: vector(106, 91, 175) },
  ];
  return { model, parts, pins, wheels, intakeRollers, emitter: m.emitter };
}

export function createStudio(renderer) {
  const studio = new THREE.Scene();
  studio.background = new THREE.Color(0x13121f);
  function panel(width, height, intensity, x, y, z, color) {
    const material = new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(intensity) });
    const object = mesh(studio, new THREE.PlaneGeometry(width, height), material, x, y, z);
    object.lookAt(0, 0, 0);
  }
  panel(545, 388, 4.5, -440, 510, 300, 0xffead2);
  panel(116, 645, 6.2, 438, 180, 132, 0xc9ddff);
  panel(482, 96, 5.4, -58, 270, -455, 0xc5a4ff);
  
  const pmrem = new THREE.PMREMGenerator(renderer);
  const studioMap = pmrem.fromScene(studio, .04, 10, 1800);
  pmrem.dispose();
  studio.traverse((object) => {
    if (!object.isMesh) return;
    object.geometry.dispose();
    object.material.dispose();
  });
  return studioMap;
}

export function makeShadow() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const gradient = ctx.createRadialGradient(64, 64, 6, 64, 64, 63);
  gradient.addColorStop(0, 'rgba(8,5,15,.82)');
  gradient.addColorStop(.52, 'rgba(8,5,15,.58)');
  gradient.addColorStop(1, 'rgba(8,5,15,0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 128, 128);
  const texture = new THREE.CanvasTexture(canvas);
  const shadow = new THREE.Mesh(new THREE.PlaneGeometry(580, 490), new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false }));
  shadow.rotation.x = -PI / 2;
  shadow.position.y = .6;
  return shadow;
}

