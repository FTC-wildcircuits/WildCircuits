const base = [
  { id: 'hero', label: 'REVEAL', angle: .73, elevation: .31, frame: 589, focus: [0, 110, 7], x: .225, y: .011, phoneFrame: 540, phoneY: .181, explode: 0, speed: .04, tint: '#614781' },
  { id: 'robot', label: 'DRIVE / CLOSE-UP', angle: 1.55, elevation: .26, frame: 182, focus: [172, 55, 141], x: -.188, y: .073, phoneFrame: 201, phoneY: .195, explode: 0, speed: .36, tint: '#51416d' },
  { id: 'intake', label: 'INTAKE / CLOSE-UP', angle: .17, elevation: .31, frame: 333, focus: [0, 78, 174], x: .224, y: .080, phoneFrame: 387, phoneY: .20, explode: 0, speed: .04, tint: '#62503f' },
  { id: 'apart', label: 'EXPLODED ASSEMBLY', angle: .81, elevation: .55, frame: 797, focus: [0, 176, 28], x: .16, y: -.022, phoneFrame: 719, phoneY: .176, explode: 1, speed: 0, tint: '#55427d' },
  { id: 'orbit', label: 'CONTROL / ORBIT', angle: -1.29, elevation: .76, frame: 789, focus: [-24, 172, -17], x: -.21, y: -.025, phoneFrame: 701, phoneY: .177, explode: 1, speed: 0, tint: '#3b4b78' },
  { id: 'rebuild', label: 'REBUILD / POWER', angle: -.51, elevation: .26, frame: 604, focus: [0, 111, 0], x: .218, y: .004, phoneFrame: 505, phoneY: .179, explode: 0, speed: .05, tint: '#525963' },
  { id: 'field', label: 'FIELD READY', angle: -2.37, elevation: .41, frame: 627, focus: [0, 100, 0], x: -.235, y: .004, phoneFrame: 506, phoneY: .177, explode: 0, speed: .42, tint: '#45355d' },
];

export const shots = base;
export const clamp = (value, low = 0, high = 1) => Math.max(low, Math.min(high, value));
export const lerp = (from, to, amount) => from + (to - from) * amount;
export function smooth(value) {
  const t = clamp(value);
  return t * t * (3 - 2 * t);
}

function mixTint(from, to, blend) {
  return 'color-mix(in oklab, ' + from + ', ' + to + ' ' + Math.round(blend * 100) + '%)';
}

export function startDirector() {
  const film = document.querySelector('#film');
  const chrome = film.querySelector('.lab-chrome');
  const menu = chrome.querySelector('.lab-menu');
  const beats = Array.from(film.querySelectorAll('[data-scene]'));
  const links = Array.from(chrome.querySelectorAll('.film-chapters a, .film-steps a'));
  const shot = film.querySelector('#shot-name');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const state = { from: 0, to: 0, blend: 0, index: 0, visible: true, progress: 0, change: null };
  let anchors = [];
  let filmEnd = 0;
  let pending = false;
  let measured = false;
  let currentIndex = -1;
  let currentVisible;
  const initialTop = film.getBoundingClientRect().top + window.scrollY;

  function read() {
    pending = false;
    const y = window.scrollY;
    const viewportHeight = window.innerHeight;
    if (!measured) {
      anchors = beats.map((element) => element.getBoundingClientRect().top + y);
      filmEnd = film.getBoundingClientRect().bottom + y;
      measured = true;
    }
    let from = 0;
    while (from < anchors.length - 1 && y >= anchors[from + 1]) from += 1;
    const to = Math.min(from + 1, anchors.length - 1);
    const phase = from === to ? 0 : clamp((y - anchors[from]) / (anchors[to] - anchors[from]));
    const blend = smooth((phase - .31) / .60);
    const index = phase >= .62 ? to : from;
    const visible = y < filmEnd - viewportHeight * .42;
    const progress = clamp((y - initialTop) / Math.max(1, filmEnd - viewportHeight - initialTop));

    if (index !== currentIndex) {
      currentIndex = index;
      film.dataset.shot = shots[index].id;
      shot.textContent = String(index + 1).padStart(2, '0') + ' / ' + shots[index].label;
      for (const link of links) {
        if (link.hash === '#' + shots[index].id) link.setAttribute('aria-current', 'step');
        else link.removeAttribute('aria-current');
      }
    }
    if (visible !== currentVisible) {
      currentVisible = visible;
      film.classList.toggle('is-offscreen', !visible);
      chrome.inert = !visible;
      if (!visible) {
        menu.open = false;
        film.querySelector('canvas').tabIndex = -1;
      } else if (film.classList.contains('is-live')) {
        film.querySelector('canvas').tabIndex = 0;
      }
    }
    film.style.setProperty('--progress', progress.toFixed(4));
    const tint = mixTint(shots[from].tint, shots[to].tint, reduce.matches ? (index === to ? 1 : 0) : blend);
    film.style.setProperty('--tint', tint);
    if (visible && !reduce.matches) {
      for (const [i, beat] of beats.entries()) {
        if (Math.abs(i - index) > 1) continue;
        const local = clamp((y - anchors[i]) / viewportHeight, -1, 1);
        const strength = 1 - Math.min(Math.abs(local) * .3, .22);
        beat.style.setProperty('--copy-y', (local * -19).toFixed(1) + 'px');
        beat.style.setProperty('--reveal', strength.toFixed(3));
      }
    }
    const changed = state.index !== index || state.visible !== visible;
    Object.assign(state, { from, to, blend, index, visible, progress });
    if (changed) state.change?.();
  }

  function queue() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(read);
  }

  window.addEventListener('scroll', queue, { passive: true });
  window.addEventListener('resize', () => { measured = false; queue(); }, { passive: true });
  document.fonts.ready.then(() => { measured = false; queue(); });
  read();
  return state;
}


