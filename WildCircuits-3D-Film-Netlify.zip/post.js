import * as THREE from './vendor/three.module.min.js';

export function soundKit() {
  let context;
  let noise;
  let enabled = false;

  async function enable() {
    const Audio = window.AudioContext || window.webkitAudioContext;
    if (!Audio) return false;
    try {
      context ||= new Audio();
      if (context.state === 'suspended') await context.resume();
      if (!noise) {
        noise = context.createBuffer(1, Math.floor(context.sampleRate * .08), context.sampleRate);
        const samples = noise.getChannelData(0);
        for (let i = 0; i < samples.length; i += 1) samples[i] = (Math.random() * 2 - 1) * (1 - i / samples.length);
      }
      enabled = true;
      return true;
    } catch {
      return false;
    }
  }

  function tick(accent = false) {
    if (!enabled || context.state !== 'running') return;
    const start = context.currentTime;
    const source = context.createBufferSource();
    const filter = context.createBiquadFilter();
    const gain = context.createGain();
    filter.type = 'bandpass';
    filter.frequency.value = accent ? 830 : 1330;
    filter.Q.value = 1.1;
    gain.gain.setValueAtTime(accent ? .1 : .035, start);
    gain.gain.exponentialRampToValueAtTime(.001, start + .06);
    source.buffer = noise;
    source.connect(filter).connect(gain).connect(context.destination);
    source.start(start);
  }

  return { enable, disable: () => { enabled = false; }, tick };
}

export function createGlintPass() {
  const target = new THREE.WebGLRenderTarget(1, 1, { type: THREE.HalfFloatType, samples: 2, depthBuffer: true });
  const material = new THREE.ShaderMaterial({
    uniforms: { source: { value: target.texture }, texel: { value: new THREE.Vector2(1, 1) } },
    depthTest: false,
    depthWrite: false,
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = vec4(position.xy, 0., 1.);
      }
    `,
    fragmentShader: `
      uniform sampler2D source;
      uniform vec2 texel;
      varying vec2 vUv;
      vec3 highlight(vec2 uv) {
        vec3 rgb = texture2D(source, uv).rgb;
        return clamp(rgb - vec3(1.25), 0., 3.);
      }
      void main() {
        vec4 base = texture2D(source, vUv);
        vec2 stepSize = texel * 3.4;
        vec3 glow = vec3(0.);
        glow += highlight(vUv + vec2(stepSize.x, 0.));
        glow += highlight(vUv - vec2(stepSize.x, 0.));
        glow += highlight(vUv + vec2(0., stepSize.y));
        glow += highlight(vUv - vec2(0., stepSize.y));
        glow += highlight(vUv + stepSize * vec2(1.4, 1.4)) * .35;
        glow += highlight(vUv - stepSize * vec2(1.4, 1.4)) * .35;
        float alpha = max(base.a, min(.18, max(glow.r, max(glow.g, glow.b)) * .017));
        gl_FragColor = vec4((base.rgb + glow * .045) / max(.001, alpha), alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        float grain = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
        gl_FragColor.rgb = max(vec3(0.), gl_FragColor.rgb + (grain - .5) * .022) * alpha;
      }
    `,
  });
  const scene = new THREE.Scene();
  scene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material));
  const camera = new THREE.Camera();
  return {
    compile(renderer) { return renderer.compileAsync(scene, camera); },
    dispose() {
      target.dispose();
      material.dispose();
      scene.children[0].geometry.dispose();
    },
    resize(width, height) {
      target.setSize(width, height);
      material.uniforms.texel.value.set(1 / width, 1 / height);
    },
    render(renderer, world, perspective) {
      renderer.setRenderTarget(target);
      renderer.render(world, perspective);
      renderer.setRenderTarget(null);
      renderer.render(scene, camera);
    },
  };
}

